/**
 * Exposes necessary information so slimerjs will work with phantom drivers.
 */
var path = require('path');
exports.path = path.join(__dirname, '../', 'src', 'slimerjs');
